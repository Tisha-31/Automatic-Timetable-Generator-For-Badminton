from flask import Flask, render_template, request
import random
from datetime import datetime, timedelta

app = Flask(__name__)

# List of countries and players
countries = ["India", "Australia", "Japan", "China", "Korea", "America"]
players = {
    "India": ["Prannoy H.S", "Lakshya Sen", "Pusarla V. Sindhu"],
    "Australia": ["Setyana Mapasa", "Gronya Somerville", "Tiffany Ho"],
    "Japan": ["Kodai Naraoka", "Kenta Nishimoto", "Kento Momota"],
    "China": ["Li Shi Feng", "Han Yue", "Lu Guang Zu"],
    "Korea": ["lee chunwi", "kin mehun", "jin sako"], 
    "America": ["glen philips", "Robin stocks", "Shawn Mendes"]
}

# Initialize schedule
schedule = []

@app.route('/')
def login():
    return render_template('login.html')
@app.route('/index')
def index():
    return render_template('index.html', countries=countries)

@app.route('/schedule', methods=['GET', 'POST'])
def badminton_schedule():
    if request.method == 'POST':    
        selected_countries = request.form.getlist('country')
        generate_schedule(selected_countries)
    return render_template('schedule.html', schedule=schedule)

def generate_schedule(selected_countries):
    global schedule
    matchups = [(country1, country2) for country1 in selected_countries for country2 in countries if country1 != country2]

    start_date = datetime(2023, 11, 17, 9, 0)  # Start date and time for scheduling
    match_duration = timedelta(hours=2)  # Duration of each match

    schedule = []  # Reset the schedule

    for matchup in matchups:
        country1, country2 = matchup
        random_date = start_date + timedelta(days=random.randint(1, 10))
        random_time = timedelta(hours=random.randint(9, 18))
        match_datetime = random_date + random_time
        schedule.append((match_datetime, country1, random.choice(players[country1]), country2, random.choice(players[country2])))
        start_date = match_datetime + match_duration

    # Sort the schedule by date and time
    schedule.sort(key=lambda x: x[0])

if __name__ == '__main__':
    app.run(debug=True)
